package com.example.qcm_software

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
